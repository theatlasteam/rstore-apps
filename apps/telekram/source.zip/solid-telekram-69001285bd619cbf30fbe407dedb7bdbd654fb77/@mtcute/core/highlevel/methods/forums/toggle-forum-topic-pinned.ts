import type { ITelegramClient } from '../../client.types.js'
import type { ForumTopic, InputPeerLike } from '../../types/index.js'
import { resolvePeer } from '../users/resolve-peer.js'

/**
 * Toggle whether a topic in a forum is pinned
 *
 * Only admins with `manageTopics` permission can do this.
 */
export async function toggleForumTopicPinned(
  client: ITelegramClient,
  params: {
    /** Chat ID or username */
    chatId: InputPeerLike
    /** ID of the topic (i.e. its top message ID, see note at {@link createForumTopic}) */
    topicId: number | ForumTopic
    /** Whether the topic should be pinned */
    pinned: boolean
  },
): Promise<void> {
  const { chatId, topicId, pinned } = params

  await client.call({
    _: 'messages.updatePinnedForumTopic',
    peer: await resolvePeer(client, chatId),
    topicId: typeof topicId === 'number' ? topicId : topicId.id,
    pinned,
  })
}
