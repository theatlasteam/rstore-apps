import type { tl } from '../../../tl/index.js'

import type { ITelegramClient } from '../../client.types.js'
import { MtcuteError } from '../../../types/errors.js'
import { assertTypeIs, hasValueAtKey } from '../../../utils/type-assertions.js'
import { PeersIndex, Story } from '../../types/index.js'
import { assertIsUpdatesGroup } from '../../updates/utils.js'

/** @internal */
export function _findStoryInUpdate(client: ITelegramClient, res: tl.TypeUpdates): Story {
  assertIsUpdatesGroup(res)

  client.handleClientUpdate(res, true)

  const peers = PeersIndex.from(res)
  const updateStory = res.updates.find(hasValueAtKey('_', 'updateStory'))

  if (!updateStory) {
    throw new MtcuteError('Response does not contain updateStory')
  }

  assertTypeIs(updateStory.story, 'storyItem')

  return new Story(updateStory.story, peers)
}
