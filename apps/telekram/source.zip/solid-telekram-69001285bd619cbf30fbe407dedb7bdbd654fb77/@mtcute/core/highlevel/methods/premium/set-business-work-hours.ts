import type { tl } from '../../../tl/index.js'

import type { ITelegramClient } from '../../client.types.js'
import type { BusinessWorkHoursDay } from '../../types/premium/business-work-hours.js'
import { assertTrue } from '../../../utils/type-assertions.js'
import { businessWorkHoursDaysToRaw } from '../../types/premium/business-work-hours.js'

// @available=user
/**
 * Set current user's business work hours.
 */
export async function setBusinessWorkHours(
  client: ITelegramClient,
  params:
        | ({
          /** Timezone in which the hours are defined */
          timezone: string
        } & (
          | {
            /**
             * Business work intervals, per-day (like available in {@link BusinessWorkHours.days})
             */
            hours: ReadonlyArray<BusinessWorkHoursDay>
          }
          | {
            /** Business work intervals, raw intervals */
            intervals: tl.TypeBusinessWeeklyOpen[]
          }
          ))
          | null,
): Promise<void> {
  let businessWorkHours: tl.TypeBusinessWorkHours | undefined

  if (params) {
    let weeklyOpen: tl.TypeBusinessWeeklyOpen[]

    if ('hours' in params) {
      weeklyOpen = businessWorkHoursDaysToRaw(params.hours)
    } else {
      weeklyOpen = params.intervals
    }

    businessWorkHours = {
      _: 'businessWorkHours',
      timezoneId: params.timezone,
      weeklyOpen,
    }
  }

  const res = await client.call({
    _: 'account.updateBusinessWorkHours',
    businessWorkHours,
  })

  assertTrue('account.updateBusinessWorkHours', res)
}
